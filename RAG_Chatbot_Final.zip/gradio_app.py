import shutil
from pathlib import Path
import os
import sys
from typing import List, Tuple, Dict, Any
import pandas as pd # Import pandas

import gradio as gr

# Add current directory to path to import local modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    # Import the updated functions from chatbot.py
    from chatbot import ingest_documents, answer_question, clear_all, get_vector_store_info, answer_question_web_search
except ImportError as e:
    print(f"❌ Import Error: {e}")
    print("Make sure chatbot.py is in the same directory and all dependencies are installed")
    sys.exit(1)

# ── paths ──────────────────────────────────────────────────────────
UPLOAD_DIR = Path("uploaded_files")
UPLOAD_DIR.mkdir(exist_ok=True)

# --- Predefined Q&A setup ---
PREDEFINED_QA_FILE = "predefined_qa.csv"
predefined_qa_data = {}

# Load predefined Q&A once at startup
try:
    df_qa = pd.read_csv(PREDEFINED_QA_FILE)
    for index, row in df_qa.iterrows():
        # Store questions in lowercase for case-insensitive matching
        predefined_qa_data[row['question'].lower().strip()] = row['answer'].strip()
    print(f"✅ Loaded {len(predefined_qa_data)} predefined Q&A pairs from {PREDEFINED_QA_FILE}")
except FileNotFoundError:
    print(f"⚠️ Warning: {PREDEFINED_QA_FILE} not found. No predefined Q&A loaded.")
except Exception as e:
    print(f"❌ Error loading predefined Q&A from {PREDEFINED_QA_FILE}: {e}. Please ensure answers with commas are enclosed in double quotes.")
# --- End Predefined Q&A setup ---


def handle_upload(filepaths):
    """
    Copy files into ./uploaded_files/, run ingestion, and return updated chat history.
    """
    chat_history = []
    upload_message = "" # For the pop-up

    if not filepaths:
        chat_history.append({"role": "assistant", "content": "❌ No files selected."})
        upload_message = "No files selected for upload."
        # Return a tuple matching the outputs signature, including a dummy for gr.Info
        return chat_history, [], gr.Info(upload_message)

    # Clear previous uploads to ensure a fresh start for each upload session
    if UPLOAD_DIR.exists():
        shutil.rmtree(UPLOAD_DIR)
    UPLOAD_DIR.mkdir(exist_ok=True)

    # Copy selected files to the UPLOAD_DIR
    uploaded_file_names = []
    for fp in filepaths:
        try:
            src = Path(fp)
            dest = UPLOAD_DIR / src.name
            shutil.copy(src, dest, follow_symlinks=True)
            uploaded_file_names.append(src.name)
            # Display file name in chat history immediately upon upload
            chat_history.append({"role": "assistant", "content": f"✅ Uploaded: **{src.name}**"})
        except Exception as e:
            chat_history.append({"role": "assistant", "content": f"❌ Error uploading {src.name}: {str(e)}"})
            upload_message = f"Error uploading {src.name}. Check console."

    # Ingest the documents from the UPLOAD_DIR and display log messages
    try:
        n_docs, n_chunks, load_log = ingest_documents(UPLOAD_DIR)
        for line in load_log:
            chat_history.append({"role": "assistant", "content": line})
        chat_history.append({"role": "assistant", "content": f"📦 Indexed {n_docs} documents → {n_chunks} chunks. Ready for questions!"})
        upload_message = f"Successfully processed {n_docs} documents!"
    except Exception as e:
        chat_history.append({"role": "assistant", "content": f"❌ Ingestion Error: {str(e)}. Please check the console for more details."})
        print(f"Detailed Ingestion Error: {e}") # Print detailed error to console for debugging
        upload_message = f"Document processing failed: {str(e)}"

    # Return a tuple matching the outputs signature, including a dummy for gr.Info
    return chat_history, [], gr.Info(upload_message)

def handle_rag_query(query, chat_history):
    """
    Handle queries specifically for RAG (document-based) answers.
    """
    if not query.strip():
        return chat_history, ""

    # Append user's question to history immediately for display
    # Gradio automatically handles user/assistant roles based on the dict structure
    chat_history.append({"role": "user", "content": query})
    
    # --- Check for predefined answer first ---
    normalized_query = query.lower().strip()
    if normalized_query in predefined_qa_data:
        predefined_answer = predefined_qa_data[normalized_query]
        chat_history.append({"role": "assistant", "content": f"Predefined Answer: {predefined_answer}"})
        return chat_history, "" # Return predefined answer and clear input
    # --- End predefined answer check ---

    # Convert Gradio chat history format to LangChain's expected format (tuple of (human, ai))
    langchain_chat_history = []
    # Iterate through chat_history in pairs (user, assistant)
    for i in range(0, len(chat_history) - 1, 2):
        if chat_history[i]['role'] == 'user' and (i + 1 < len(chat_history) and chat_history[i+1]['role'] == 'assistant'):
            langchain_chat_history.append((chat_history[i]['content'], chat_history[i+1]['content']))
    
    answer, sources = answer_question(query, langchain_chat_history)
    
    if sources:
        source_list = ", ".join(sources)
        answer_with_sources = f"{answer}\n\nSources: {source_list}"
    else:
        answer_with_sources = answer
    
    chat_history.append({"role": "assistant", "content": answer_with_sources})
    
    return chat_history, "" # Return updated history and clear the input textbox

def handle_web_search_query(query, chat_history):
    """
    Handle queries specifically for web search answers.
    """
    if not query.strip():
        return chat_history, ""

    # Append user's question to history immediately for display
    chat_history.append({"role": "user", "content": query})

    # Temporarily append a "thinking" message while waiting for web search and LLM
    chat_history.append({"role": "assistant", "content": "Searching the web and thinking..."})
    yield chat_history, "" # Update UI with thinking message

    answer, sources = answer_question_web_search(query)
    
    # Remove the "thinking" message before adding the final answer
    if chat_history and chat_history[-1].get("content") == "Searching the web and thinking...":
        chat_history.pop()

    if sources:
        source_list = ", ".join(sources)
        answer_with_sources = f"Web Search Result:\n\n{answer}\n\nSources: {source_list}"
    else:
        answer_with_sources = f"Web Search Result:\n\n{answer}"
            
    chat_history.append({"role": "assistant", "content": answer_with_sources})
    
    return chat_history, "" # Return updated history and clear the input textbox

def clear_rag_chat():
    """Clears the RAG chat history."""
    return [], ""

def clear_web_search_chat():
    """Clears the Web Search chat history."""
    return [], ""

# ── Gradio Interface ───────────────────────────────────────────────
# Custom CSS for a cooler look
custom_css = """
body {
    font-family: 'Inter', sans-serif;
    background-color: #1a1a2e; /* Dark background */
    color: #e0e0e0; /* Light text */
}
.gradio-container {
    background-color: #2a2a4a; /* Slightly lighter dark for container */
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    padding: 20px;
}
h1 {
    color: #00bcd4; /* Teal for heading */
    text-align: center;
    font-size: 2.5em;
    margin-bottom: 20px;
    text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
}
.gr-button {
    background-color: #00bcd4; /* Teal buttons */
    color: white;
    border-radius: 8px;
    padding: 10px 20px;
    font-weight: bold;
    transition: background-color 0.3s ease, transform 0.2s ease;
}
.gr-button:hover {
    background-color: #0097a7; /* Darker teal on hover */
    transform: translateY(-2px);
}
.gr-textbox, .gr-file {
    background-color: #3a3a5a; /* Darker input fields */
    color: #e0e0e0;
    border: 1px solid #5a5a7a;
    border-radius: 8px;
}
.gr-textbox:focus, .gr-file:focus {
    border-color: #00bcd4;
    box-shadow: 0 0 0 2px rgba(0, 188, 212, 0.5);
}
.gr-chatbot {
    border-radius: 10px;
    background-color: #3a3a5a; /* Chatbot background */
}
.gr-chatbot .message.user {
    background-color: #00bcd4; /* User message bubble */
    color: white;
    border-radius: 15px 15px 0 15px;
}
.gr-chatbot .message.bot {
    background-color: #5a5a7a; /* Bot message bubble */
    color: white;
    border-radius: 15px 15px 15px 0;
}
.gr-tab-item {
    color: #e0e0e0;
    font-weight: bold;
}
.gr-tab-item.selected {
    color: #00bcd4;
    border-bottom: 2px solid #00bcd4;
}
.gr-radio-group {
    background-color: #3a3a5a;
    border-radius: 8px;
    padding: 10px;
}
.gr-radio-label {
    color: #e0e0e0;
}
"""

with gr.Blocks(title="Gator Chatbot", css=custom_css) as demo:
    gr.Markdown("# Gator Chatbot")
    
    with gr.Tab("Upload Files"):
        gr.Markdown("## Upload Your Documents Here")
        file_input = gr.Files(label="Drag and Drop Files Here", file_types=[".pdf", ".txt", ".docx", ".xlsx", ".csv"], file_count="multiple")
        upload_button = gr.Button("Process Documents", elem_id="process_documents_button")
        # Dummy component to capture gr.Info messages
        info_output = gr.HTML(visible=False) 
        
    with gr.Tab("RAG Chat"):
        rag_chatbot = gr.Chatbot(height=500, label="Chat with your Documents", type="messages", show_label=False)
        rag_msg = gr.Textbox(label="Ask a question about your documents", placeholder="Type your question here...", container=False)
        
        with gr.Row():
            rag_submit_button = gr.Button("Ask Document Gator", variant="primary")
            rag_clear_chat_button = gr.ClearButton([rag_msg, rag_chatbot])
        
    with gr.Tab("Web Search Chat"):
        web_search_chatbot = gr.Chatbot(height=500, label="General Chat (Web Search)", type="messages", show_label=False)
        web_search_msg = gr.Textbox(label="Ask a general question (uses web search)", placeholder="Type your question here...", container=False)
        
        with gr.Row():
            web_search_submit_button = gr.Button("Ask Web Gator", variant="primary")
            web_search_clear_chat_button = gr.ClearButton([web_search_msg, web_search_chatbot])

    with gr.Tab("Settings"):
        gr.Markdown("## Chatbot Settings")
        clear_all_button = gr.Button("Clear All Data (Vector Store & All Chat Histories)")
        info_button = gr.Button("Show Vector Store Info")
        info_text = gr.Textbox(label="Status / Vector Store Information", interactive=False)

    # Event Handlers
    upload_button.click(
        fn=handle_upload,
        inputs=[file_input],
        outputs=[rag_chatbot, file_input, info_output] # Added info_output here
    )
    
    rag_msg.submit(
        fn=handle_rag_query,
        inputs=[rag_msg, rag_chatbot],
        outputs=[rag_chatbot, rag_msg]
    )
    
    rag_submit_button.click(
        fn=handle_rag_query,
        inputs=[rag_msg, rag_chatbot],
        outputs=[rag_chatbot, rag_msg]
    )

    web_search_msg.submit(
        fn=handle_web_search_query,
        inputs=[web_search_msg, web_search_chatbot],
        outputs=[web_search_chatbot, web_search_msg]
    )

    web_search_submit_button.click(
        fn=handle_web_search_query,
        inputs=[web_search_msg, web_search_chatbot],
        outputs=[web_search_chatbot, web_search_msg]
    )
    
    # Clear buttons for individual chat tabs
    rag_clear_chat_button.click(
        fn=clear_rag_chat,
        inputs=[],
        outputs=[rag_msg, rag_chatbot]
    )

    web_search_clear_chat_button.click(
        fn=clear_web_search_chat,
        inputs=[],
        outputs=[web_search_msg, web_search_chatbot]
    )

    clear_all_button.click(
        fn=clear_all,
        outputs=[rag_chatbot, web_search_chatbot, info_text]
    )
    
    info_button.click(
        fn=get_vector_store_info,
        outputs=[info_text]
    )

if __name__ == "__main__":
    demo.launch()
