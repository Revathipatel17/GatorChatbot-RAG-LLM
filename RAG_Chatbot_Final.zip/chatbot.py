import os
import sys
import io
import contextlib
import shutil
import unicodedata
import torch
from langchain_huggingface import HuggingFacePipeline 
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
from pathlib import Path
from typing import List, Tuple, Optional
from dotenv import load_dotenv

# --- Utility functions moved to the top to ensure they are defined before use ---
def safe_print(text):
    """Safely print text to stdout, handling potential encoding issues."""
    try:
        if not isinstance(text, str):
            text = str(text)
        sys.__stdout__.write(text.encode('utf-8', 'ignore').decode('utf-8') + '\n')
    except Exception as e:
        sys.__stdout__.write(f"[Print Error: {e}]\n")

@contextlib.contextmanager
def suppress_stdout_stderr():
    """Context manager to suppress stdout and stderr, useful for noisy libraries."""
    with open(os.devnull, 'w') as fnull:
        with contextlib.redirect_stdout(fnull), contextlib.redirect_stderr(fnull):
            yield
# --- End of utility functions ---

safe_print("DEBUG: chatbot.py started execution.")

# ── CONFIG ──────────────────────────────────────────────
# Move the dotenv load to the top
load_dotenv("key.env")
safe_print(f"DEBUG: .env loaded. SERPAPI_API_KEY present: {os.getenv('SERPAPI_API_KEY') is not None and len(os.getenv('SERPAPI_API_KEY')) > 0}")

# Suppress HuggingFace tokenizer fork warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"
safe_print("DEBUG: TOKENIZERS_PARALLELISM set.")

# Import LangChain components for document loading and splitting
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import (
    PyMuPDFLoader,
    UnstructuredWordDocumentLoader,
    UnstructuredExcelLoader,
    TextLoader,
    CSVLoader,
    PyPDFLoader,
)
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
safe_print("DEBUG: LangChain document components imported.")

# New imports for HuggingFace LLM and Conversational Chain
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain_core.prompts import PromptTemplate
safe_print("DEBUG: HuggingFace LLM components imported.")


# Robust import for the main chain
try:
    from langchain.chains import RetrievalQA
except ImportError:
    try:
        from langchain_community.chains import RetrievalQA
    except ImportError:
        RetrievalQA = None
safe_print(f"DEBUG: RetrievalQA import status: {RetrievalQA is not None}")

# Robust import and initialization for the search tool (using SerpAPIWrapper directly)
try:
    from langchain_community.utilities import SerpAPIWrapper
    _search_tool = SerpAPIWrapper(serpapi_api_key=os.getenv("SERPAPI_API_KEY"))
    _search_tool_available = True
    safe_print("✅ Loaded SerpApi search tool.")
except Exception as e:
    _search_tool_available = False
    safe_print(f"❌ SerpApi search tool is not available: {str(e)}")
safe_print(f"DEBUG: Search tool initialization status: {_search_tool_available}")


EMBED_MODEL = os.getenv("EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
CHROMA_DIR = os.getenv("CHROMA_DB_DIR", "chroma_db")

# Robust parsing of integer environment variables
try:
    CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "800"))
except ValueError:
    safe_print("Warning: CHUNK_SIZE in key.env is not an integer. Using default 800.")
    CHUNK_SIZE = 800
try:
    CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "100"))
except ValueError:
    safe_print("Warning: CHUNK_OVERLAP in key.env is not an integer. Using default 100.")
    CHUNK_OVERLAP = 100
try:
    TOP_K = int(os.getenv("TOP_K", "5"))
except ValueError:
    safe_print("Warning: TOP_K in key.env is not an integer. Using default 5.")
    TOP_K = 5

LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "mistralai/Mistral-7B-Instruct-v0.2")
try:
    LLM_MAX_NEW_TOKENS = int(os.getenv("LLM_MAX_NEW_TOKENS", "512"))
except ValueError:
    safe_print("Warning: LLM_MAX_NEW_TOKENS in key.env is not an integer. Using default 512.")
    LLM_MAX_NEW_TOKENS = 512
safe_print("DEBUG: All config variables parsed.")

# Global variables
docs_store = None
embeddings = None
llm_tokenizer = None
llm_model = None
llm_pipeline = None
llm_chain = None  # For RAG
safe_print("DEBUG: Global variables initialized to None.")

# --- Functions directly imported by gradio_app.py, moved up for robustness ---
def get_vector_store_info():
    """Get information about the current vector store status."""
    global docs_store
    if docs_store is None:
        if load_existing_vector_store():
            return get_vector_store_info()
        else:
            return "No vector store loaded"
    try:
        collection = docs_store._collection
        count = collection.count()
        return f"Vector store contains {count} document chunks"
    except Exception as e:
        safe_print(f"Error getting vector store info: {str(e)}")
        return f"Error getting vector store info: {normalize_text(str(e))}"

def clear_all():
    """Reset the vector store, LLM components, and clear all data."""
    global docs_store, embeddings, llm_tokenizer, llm_model, llm_pipeline, llm_chain
    docs_store = None
    embeddings = None
    llm_tokenizer = None
    llm_model = None
    llm_pipeline = None
    llm_chain = None
    clean_chroma_db()
    safe_print("✅ Cleared all data and reset vector store and LLM chain.")
    return [], [], "" # Return empty lists for chat histories and empty string for info
# --- End of moved functions ---


def initialize_embeddings():
    """Initialize embeddings model once."""
    global embeddings
    if embeddings is None:
        safe_print(f"DEBUG: Initializing embeddings with model: {EMBED_MODEL}")
        embeddings = HuggingFaceEmbeddings(
            model_name=EMBED_MODEL,
            model_kwargs={'device': 'cpu'},
            encode_kwargs={'normalize_embeddings': True}
        )
        safe_print("DEBUG: Embeddings initialized.")
    return embeddings

def initialize_llm_components():
    """
    Initialize the HuggingFace LLM components (tokenizer, model, pipeline, chain)
    and the ConversationalRetrievalChain.
    """
    global llm_tokenizer, llm_model, llm_pipeline, llm_chain, docs_store

    if llm_tokenizer is None:
        safe_print(f"DEBUG: Loading tokenizer: {LLM_MODEL_NAME}")
        try:
            llm_tokenizer = AutoTokenizer.from_pretrained(LLM_MODEL_NAME)
            if llm_tokenizer.pad_token is None:
                llm_tokenizer.pad_token = llm_tokenizer.eos_token
            safe_print("DEBUG: Tokenizer loaded.")
        except Exception as e:
            safe_print(f"ERROR: Error loading tokenizer: {e}")
            safe_print("DEBUG: Attempting to load 'gpt2' as a fallback LLM model.")
            LLM_MODEL_NAME_FALLBACK = "gpt2"
            llm_tokenizer = AutoTokenizer.from_pretrained(LLM_MODEL_NAME_FALLBACK)
            if llm_tokenizer.pad_token is None:
                llm_tokenizer.pad_token = llm_tokenizer.eos_token
            safe_print("DEBUG: Fallback tokenizer loaded.")

    if llm_model is None:
        safe_print(f"DEBUG: Loading model: {LLM_MODEL_NAME}")
        try:
            llm_model = AutoModelForCausalLM.from_pretrained(
                LLM_MODEL_NAME,
                device_map='auto',
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            )
            safe_print("DEBUG: Model loaded.")
        except Exception as e:
            safe_print(f"ERROR: Error loading model: {e}")
            safe_print("DEBUG: Attempting to load 'gpt2' as a fallback LLM model.")
            llm_model = AutoModelForCausalLM.from_pretrained("gpt2")
            safe_print("DEBUG: Fallback model loaded.")

    if llm_pipeline is None:
        safe_print("DEBUG: Creating text generation pipeline.")
        llm_pipeline = pipeline(
            model=llm_model,
            task='text-generation',
            tokenizer=llm_tokenizer,
            max_new_tokens=LLM_MAX_NEW_TOKENS,
            do_sample=True,
            temperature=0.7,
            top_p=0.95,
            eos_token_id=llm_tokenizer.eos_token_id,
            pad_token_id=llm_tokenizer.pad_token_id
        )
        safe_print("DEBUG: Pipeline created.")

    hf_llm = HuggingFacePipeline(pipeline=llm_pipeline)
    safe_print("DEBUG: HuggingFacePipeline instance created.")

    # Simplified QA_PROMPT for cleaner output
    # This prompt is designed to make the LLM output the answer directly after "Answer:"
    qa_template = """Context: {context}
Question: {question}
Answer:"""
    QA_PROMPT = PromptTemplate(
        template=qa_template, input_variables=["context", "question"]
    )
    safe_print("DEBUG: QA_PROMPT created.")

    condense_template = """
    Given the following conversation and a follow up question, rephrase the follow up question to be a standalone question.

    Chat History:
    {chat_history}
    Follow Up Question: {question}
    Standalone Question:
    """
    CONDENSE_QUESTION_PROMPT = PromptTemplate.from_template(condense_template)
    safe_print("DEBUG: CONDENSE_QUESTION_PROMPT created.")

    if RetrievalQA and docs_store is not None and llm_chain is None:
        safe_print("DEBUG: Creating RetrievalQA chain for RAG.")
        llm_chain = RetrievalQA.from_chain_type(
            llm=hf_llm,
            retriever=docs_store.as_retriever(search_kwargs={"k": TOP_K}),
            return_source_documents=True,
            chain_type="stuff",
            chain_type_kwargs={"prompt": QA_PROMPT} # Pass the custom prompt here
        )
        safe_print("DEBUG: RetrievalQA created.")
    elif RetrievalQA and docs_store is None:
        safe_print("DEBUG: RetrievalQA not created because docs_store is None.")
    elif not RetrievalQA:
        safe_print("DEBUG: RetrievalQA not created because RetrievalQA class is not available.")
    elif llm_chain is not None:
        safe_print("DEBUG: RetrievalQA chain already initialized.")


def normalize_text(text: str) -> str:
    """Normalize text to handle encoding issues and special characters."""
    if not text:
        return ""
    text = str(text)
    text = unicodedata.normalize('NFKD', text)
    replacements = {
        '\u2011': '-', '\u2013': '-', '\u2014': '--', '\u2018': "'", '\u2019': "'",
        '\u201c': '"', '\u201d': '"', '\u2022': '•', '\u00a0': ' ', '\u2026': '...',
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = ''.join(char if ord(char) < 128 else ' ' for char in text)
    return text.strip()

def clean_chroma_db():
    """Clean existing ChromaDB directory."""
    if os.path.exists(CHROMA_DIR):
        try:
            shutil.rmtree(CHROMA_DIR)
            safe_print(f"Cleaned existing ChromaDB directory: {CHROMA_DIR}")
        except Exception as e:
            safe_print(f"Warning: Could not clean ChromaDB directory: {str(e)}")

def load_pdf_document(file_path: Path) -> List[Document]:
    documents = []
    try:
        try:
            loader = PyMuPDFLoader(str(file_path))
            docs = loader.load()
        except Exception:
            loader = PyPDFLoader(str(file_path))
            docs = loader.load()
        for doc in docs:
            doc.page_content = normalize_text(doc.page_content)
            doc.metadata['source'] = file_path.name
            doc.metadata['type'] = 'pdf'
        documents.extend(docs)
        return documents
    except Exception as e:
        safe_print(f"Error loading PDF {file_path}: {str(e)}")
        return []

def load_text_document(file_path: Path) -> List[Document]:
    documents = []
    try:
        encodings = ['utf-8', 'utf-8-sig', 'latin-1', 'cp1252']
        content = ""
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                break
            except UnicodeDecodeError:
                continue
        else:
            with open(file_path, 'rb') as f:
                content = f.read().decode('utf-8', errors='ignore')
        content = normalize_text(content)
        doc = Document(
            page_content=content,
            metadata={'source': file_path.name, 'type': 'text'}
        )
        documents.append(doc)
        return documents
    except Exception as e:
        safe_print(f"Error loading text {file_path}: {str(e)}")
        return []

def load_csv_document(file_path: Path) -> List[Document]:
    documents = []
    try:
        import pandas as pd
        df = pd.read_csv(file_path, encoding='utf-8')
        summary = f"CSV file {file_path.name} contains {len(df)} rows and {len(df.columns)} columns.\n"
        summary += f"Columns: {', '.join(df.columns)}\n\n"
        summary += "Sample data:\n" + df.head(3).to_string(index=False)
        summary = normalize_text(summary)
        documents.append(Document(
            page_content=summary,
            metadata={'source': file_path.name, 'type': 'csv_summary'}
        ))
        for idx, row in df.iterrows():
            row_content = " | ".join([f"{col}: {normalize_text(str(row[col]))}" for col in df.columns])
            documents.append(Document(
                page_content=f"Row {idx + 1}: {row_content}",
                metadata={'source': file_path.name, 'type': 'csv_row', 'row_number': idx + 1}
            ))
        return documents
    except ImportError:
        safe_print("Pandas not found, falling back to LangChain CSVLoader for CSV files.")
        loader = CSVLoader(str(file_path))
        docs = loader.load()
        for doc in docs:
            doc.page_content = normalize_text(doc.page_content)
            doc.metadata['source'] = file_path.name
            doc.metadata['type'] = 'csv'
        documents.extend(docs)
        return documents
    except Exception as e:
        safe_print(f"Error loading CSV {file_path}: {str(e)}")
        return []

def load_excel_document(file_path: Path) -> List[Document]:
    documents = []
    try:
        import pandas as pd
        df = pd.read_excel(file_path)
        summary = f"Excel file {file_path.name} contains {len(df)} rows and {len(df.columns)} columns.\n"
        summary += f"Columns: {', '.join(df.columns)}\n\n"
        summary += "Sample data:\n" + df.head(3).to_string(index=False)
        summary = normalize_text(summary)
        documents.append(Document(
            page_content=summary,
            metadata={'source': file_path.name, 'type': 'excel_summary'}
        ))
        for idx, row in df.iterrows():
            row_content = " | ".join([f"{col}: {normalize_text(str(row[col]))}" for col in df.columns])
            documents.append(Document(
                page_content=f"Row {idx + 1}: {row_content}",
                metadata={'source': file_path.name, 'type': 'excel_row', 'row_number': idx + 1}
            ))
        return documents
    except ImportError:
        safe_print("Pandas not found, falling back to UnstructuredExcelLoader for Excel files.")
        from langchain_community.document_loaders import UnstructuredExcelLoader
        loader = UnstructuredExcelLoader(str(file_path))
        docs = loader.load()
        for doc in docs:
            doc.page_content = normalize_text(doc.page_content)
            doc.metadata['source'] = file_path.name
            doc.metadata['type'] = 'excel'
        documents.extend(docs)
        return documents
    except Exception as e:
        safe_print(f"Error loading Excel {file_path}: {str(e)}")
        return []

def load_docx_document(file_path: Path) -> List[Document]:
    documents = []
    try:
        try:
            import docx
            doc = docx.Document(file_path)
            for table_idx, table in enumerate(doc.tables):
                if table.rows:
                    headers = [normalize_text(cell.text) for cell in table.rows[0].cells]
                    table_summary = f"Table {table_idx + 1} in {file_path.name} with columns: {', '.join(headers)}"
                    documents.append(Document(
                        page_content=table_summary,
                        metadata={'source': file_path.name, 'type': 'docx_table_summary', 'table_number': table_idx + 1}
                    ))
                    for row_idx, row in enumerate(table.rows[1:], 1):
                        row_data = []
                        for header, cell in zip(headers, row.cells):
                            row_data.append(f"{header}: {normalize_text(str(cell.text))}")
                        row_content = " | ".join(row_data)
                        documents.append(Document(
                            page_content=f"Row {row_idx} from table {table_idx + 1}: {row_content}", # Changed to "Row {row_idx}"
                            metadata={'source': file_path.name, 'type': 'docx_table_row', 'table_number': table_idx + 1, 'row_number': row_idx}
                        ))
        except ImportError:
            safe_print("python-docx not found, skipping enhanced table extraction for DOCX.")
        from langchain_community.document_loaders import UnstructuredWordDocumentLoader
        loader = UnstructuredWordDocumentLoader(str(file_path))
        docs = loader.load()
        for doc in docs:
            doc.page_content = normalize_text(doc.page_content)
            doc.metadata['source'] = file_path.name
            doc.metadata['type'] = 'docx'
        documents.extend(docs)
        return documents
    except Exception as e:
        safe_print(f"Error loading DOCX {file_path}: {str(e)}")
        return []

def load_documents_from_dir(directory: Path) -> List[Document]:
    """Load all supported files from a given directory into LangChain documents."""
    file_loaders = {
        ".pdf": load_pdf_document, ".txt": load_text_document, ".csv": load_csv_document,
        ".xlsx": load_excel_document, ".xls": load_excel_document,
        ".docx": load_docx_document, ".doc": load_docx_document,
    }
    all_documents = []
    for file_path in sorted(directory.iterdir()):
        if file_path.name.startswith(".") or not file_path.is_file():
            continue
        ext = file_path.suffix.lower()
        loader_func = file_loaders.get(ext)
        if not loader_func:
            safe_print(f"⚠️ Unsupported file type: {file_path.name}")
            continue
        try:
            documents = loader_func(file_path)
            all_documents.extend(documents)
            safe_print(f"Loaded {file_path.name} ({ext}) → {len(documents)} document sections")
        except Exception as e:
            safe_print(f"❌ Error loading {file_path.name}: {str(e)}")
    return all_documents

def split_documents(documents: List[Document]) -> List[Document]:
    """Split documents into smaller, manageable chunks."""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        separators=["\n\n", "\n", ".", "!", "?", ",", " ", ""]
    )
    chunks = text_splitter.split_documents(documents)
    safe_print(f"Split documents into {len(chunks)} text chunks")
    return chunks

def create_vector_store(chunks: List[Document]) -> Chroma:
    """Create and populate the Chroma vector store with document chunks."""
    global docs_store
    try:
        clean_chroma_db()
        embed_model = initialize_embeddings()
        safe_print(f"🔤 Initialized embeddings with {EMBED_MODEL}")
        docs_store = Chroma.from_documents(
            documents=chunks,
            embedding=embed_model,
            persist_directory=CHROMA_DIR
        )
        safe_print(f"🗄️ Created vector database with {len(chunks)} embeddings.")
        return docs_store
    except Exception as e:
        safe_print(f"❌ Error creating vector store: {str(e)}")
        raise

def load_existing_vector_store() -> bool:
    """Attempt to load an existing vector store from disk."""
    global docs_store
    if not os.path.exists(CHROMA_DIR):
        return False
    try:
        embed_model = initialize_embeddings()
        docs_store = Chroma(
            persist_directory=CHROMA_DIR,
            embedding_function=embed_model
        )
        test_results = docs_store.similarity_search("test", k=1)
        safe_print(f"Loaded existing vector store from {CHROMA_DIR}.")
        return True
    except Exception as e:
        safe_print(f"Error loading existing vector store: {str(e)}")
        return False

def ingest_documents(directory: Path) -> Tuple[int, int, List[str]]:
    """
    Main ingestion function: loads documents, splits them into chunks,
    builds/refreshes the Chroma vector store, and initializes the LLM chain.
    Returns (num_unique_documents, num_chunks, log_messages_for_ui).
    """
    global docs_store, llm_chain
    ui_log = []
    clean_chroma_db()
    documents = load_documents_from_dir(directory)
    if not documents:
        raise RuntimeError("No supported documents found to ingest. Please check the upload directory.")
    ui_log.append(f"📄 Loaded {len(documents)} document sections from uploaded files.")
    chunks = split_documents(documents)
    ui_log.append(f"✂️ Split into {len(chunks)} text chunks for indexing.")
    try:
        docs_store = create_vector_store(chunks)
        ui_log.append(f"🗄️ Vector database created/updated with {len(chunks)} embeddings.")
    except Exception as e:
        ui_log.append(f"❌ Error creating vector store during ingestion: {str(e)}")
        raise
    try:
        initialize_llm_components()
        ui_log.append("🧠 LLM and Retrieval Chain initialized successfully.")
    except Exception as e:
        ui_log.append(f"❌ Error initializing LLM chain after ingestion: {str(e)}")
        raise
    unique_sources = set()
    for doc in documents:
        if 'source' in doc.metadata:
            unique_sources.add(doc.metadata['source'])
    return len(unique_sources), len(chunks), ui_log

def sanitize(text: str) -> str:
    """Clean text to avoid encoding issues before processing or displaying."""
    if text is None:
        return ""
    return normalize_text(str(text))

def answer_question(question: str, chat_history: List[Tuple[str, str]]) -> Tuple[str, List[str]]:
    """
    Generate an answer to a user's question based on the loaded documents
    and current chat history. Returns (answer_text, list_of_sources).
    """
    global llm_chain, docs_store
    if docs_store is None:
        safe_print("Vector store not in memory, attempting to load from disk.")
        if not load_existing_vector_store():
            return "⚠️ Please upload and process files first before asking questions. No vector store found.", []
        try:
            safe_print("Vector store loaded, initializing LLM components.")
            initialize_llm_components()
        except Exception as e:
            return f"❌ Error initializing LLM chain after loading vector store: {normalize_text(str(e))}", []
    if llm_chain is None:
        safe_print("RAG LLM chain is not initialized. Attempting to re-initialize.")
        try:
            initialize_llm_components()
            if llm_chain is None:
                return "⚠️ RAG LLM chain could not be initialized. Please try re-uploading documents.", []
        except Exception as e:
            return f"❌ Error re-initializing RAG LLM chain: {normalize_text(str(e))}", []

    try:
        question = sanitize(question)
        safe_print(f"DEBUG: RAG answering question: {question}")
        result = llm_chain.invoke({
            "query": question, 
        })
        safe_print(f"DEBUG: RAG answer raw result: {result}")
        
        final_answer_text = ""
        if isinstance(result, dict):
            full_llm_output = result.get("result", "").strip()
            
            # Extract the answer by looking for the "Answer:" marker.
            # If not found, try to strip the known prompt structure from the beginning.
            answer_marker = "Answer:"
            if answer_marker in full_llm_output:
                final_answer_text = full_llm_output.split(answer_marker, 1)[1].strip()
            else:
                # Fallback: aggressively remove the prompt structure if "Answer:" isn't present
                # Construct the expected prompt prefix dynamically to remove it
                expected_prompt_prefix_template = QA_PROMPT.template.replace("{context}", "").replace("{question}", "").strip()
                
                # Remove any leading/trailing newlines from the template itself
                expected_prompt_prefix_template = expected_prompt_prefix_template.strip()

                if full_llm_output.startswith(expected_prompt_prefix_template):
                    final_answer_text = full_llm_output[len(expected_prompt_prefix_template):].strip()
                else:
                    final_answer_text = full_llm_output # Last resort: use raw output

            # Further clean up any remaining prompt fragments or leading/trailing newlines
            # This is a heuristic and might need adjustment based on LLM's specific output style
            prompt_fragments = [
                "Use the following pieces of context to answer the question at the end.",
                "If you don't know the answer, just state that you don't have enough information from the provided documents.",
                "Do not try to make up an answer.",
                "Context:",
                "Question:",
                "Helpful Answer:", # In case it was generated but not split by the primary logic
                question # Remove the question itself if it's echoed in the answer
            ]
            for fragment in prompt_fragments:
                # Replace fragments only if they appear at the beginning or are exact matches
                if final_answer_text.startswith(fragment.strip()):
                    final_answer_text = final_answer_text[len(fragment.strip()):].strip()
                # Also replace if it appears in the middle (less likely for prompt parts)
                final_answer_text = final_answer_text.replace(fragment.strip(), "").strip()

            # Remove any leading/trailing newlines or excessive whitespace
            final_answer_text = final_answer_text.strip()
            
            if not final_answer_text: # Fallback to 'answer' key if parsing yields empty string
                final_answer_text = result.get("answer", "").strip()
        else:
            final_answer_text = str(result).strip()

        answer = final_answer_text.encode("utf-8", "ignore").decode("utf-8")
        
        sources = set()
        if isinstance(result, dict) and 'source_documents' in result and result['source_documents']:
            for doc in result['source_documents']:
                if 'source' in doc.metadata:
                    sources.add(doc.metadata['source'])
        source_list = sorted(list(sources))
        safe_print(f"DEBUG: RAG final answer: {answer}, Sources: {source_list}")
        return answer, source_list
    except Exception as e:
        error_msg = f"❌ Error processing your question: {normalize_text(str(e))}"
        safe_print(f"ERROR: {error_msg}")
        return error_msg, []

def answer_question_web_search(question: str) -> Tuple[str, List[str]]:
    """
    Perform a web search and answer the question using the search results.
    """
    global llm_pipeline, _search_tool_available, _search_tool

    if not _search_tool_available:
        safe_print("ERROR: Web search is not configured.")
        return "❌ Web search is not configured. Please check your API key and dependencies.", []

    if llm_pipeline is None:
        safe_print("DEBUG: LLM pipeline not initialized for web search. Attempting to initialize.")
        try:
            initialize_llm_components()
            if llm_pipeline is None:
                safe_print("ERROR: LLM pipeline could not be initialized for web search.")
                return "⚠️ LLM pipeline could not be initialized for web search. Please try again later.", []
        except Exception as e:
            error_msg = f"❌ Error initializing LLM for web search: {normalize_text(str(e))}"
            safe_print(f"ERROR: {error_msg}")
            return error_msg, []

    try:
        safe_print(f"DEBUG: Performing web search for: {question}")
        # Use with suppress_stdout_stderr to prevent noisy output from web search tool
        with suppress_stdout_stderr():
            search_results_str = _search_tool.run(question)
        safe_print(f"DEBUG: Web search raw results: {search_results_str[:200]}...") # Print first 200 chars
        context = f"Web Search Results:\n{search_results_str}"
        
        # Define the prompt for the web search LLM
        web_search_llm_prompt = f"""You are a helpful AI assistant. Use the following web search results to answer the question.
        If the search results do not contain enough information, state that. Do not make up information.

        {context}

        Question: {question}

        Answer:
        """
        safe_print("DEBUG: Sending web search prompt to LLM.")
        response = llm_pipeline(web_search_llm_prompt)
        raw_answer = response[0]['generated_text'].strip()
        safe_print(f"DEBUG: LLM raw response for web search: {raw_answer[:200]}...\n") # Print first 200 chars
        
        # Extract only the answer part from the LLM's full generated text
        # This logic is similar to RAG answer extraction for consistency
        final_web_answer_text = ""
        answer_prefix = "Answer:"
        if answer_prefix in raw_answer:
            final_web_answer_text = raw_answer.split(answer_prefix, 1)[1].strip()
        else:
            # Fallback: try to strip the known prompt structure from the beginning
            # Construct the expected prompt prefix dynamically to remove it
            # Note: This is a simplified version of the web_search_llm_prompt for stripping
            expected_web_prompt_prefix = f"You are a helpful AI assistant. Use the following web search results to answer the question.\nIf the search results do not contain enough information, state that. Do not make up information.\n\nWeb Search Results:\n{search_results_str}\n\nQuestion: {question}\n\nAnswer:".strip()
            
            if raw_answer.startswith(expected_web_prompt_prefix):
                final_web_answer_text = raw_answer[len(expected_web_prompt_prefix):].strip()
            else:
                final_web_answer_text = raw_answer # Last resort: use raw output

        # Further clean up any remaining prompt fragments or leading/trailing newlines
        web_prompt_fragments = [
            "You are a helpful AI assistant. Use the following web search results to answer the question.",
            "If the search results do not contain enough information, state that. Do not make up information.",
            "Web Search Results:",
            "Question:",
            "Answer:",
            question # Remove the question itself if it's echoed
        ]
        for fragment in web_prompt_fragments:
            if final_web_answer_text.startswith(fragment.strip()):
                final_web_answer_text = final_web_answer_text[len(fragment.strip()):].strip()
            final_web_answer_text = final_web_answer_text.replace(fragment.strip(), "").strip()
        
        final_web_answer_text = final_web_answer_text.strip()


        answer = final_web_answer_text.encode("utf-8", "ignore").decode("utf-8")
        source_list = ["Web Search"]
        safe_print(f"DEBUG: Web search final answer: {answer}, Sources: {source_list}")
        return answer, source_list
    except Exception as e:
        error_msg = f"❌ Error during web search or LLM generation: {normalize_text(str(e))}"
        safe_print(f"ERROR: {error_msg}")
        return error_msg, []


if __name__ == "__main__":
    safe_print("RAG Chatbot backend starting...")
    # This block is for testing, but since gradio_app.py imports it, it won't run.
    # The Gradio app will handle the initialization.
