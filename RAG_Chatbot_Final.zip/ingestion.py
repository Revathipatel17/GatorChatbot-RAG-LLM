import os
import logging
from pathlib import Path
from typing import List
import pandas as pd
from dotenv import load_dotenv
from pydantic.v1 import BaseModel

import shutil

# Load environment variables from key.env
load_dotenv("key.env")

# Import LangChain components
from langchain_community.document_loaders import (
    PyPDFLoader, 
    TextLoader, 
    Docx2txtLoader, 
    CSVLoader,
    UnstructuredExcelLoader
)
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
DATA_DIR = Path("data")
UPLOAD_DIR = Path("uploaded_files")
CHROMA_DB_DIR = "chroma_db"
CHUNK_SIZE = 800
CHUNK_OVERLAP = 100

def get_supported_files(directory: Path = DATA_DIR) -> List[Path]:
    """Get list of supported files from directory"""
    if not directory.exists():
        logger.warning(f"Directory {directory} does not exist")
        return []
    
    supported_extensions = {'.pdf', '.txt', '.docx', '.csv', '.xlsx'}
    files = []
    
    for file_path in directory.iterdir():
        if file_path.is_file() and file_path.suffix.lower() in supported_extensions:
            files.append(file_path)
        elif file_path.is_file() and file_path.suffix.lower() not in supported_extensions:
            # Skip system files
            if not (file_path.name.startswith('.') or file_path.name == 'key.env'):
                logger.warning(f"Unsupported file type: {file_path.name}")
    
    return files

def load_csv_enhanced(file_path: Path) -> List[Document]:
    """Enhanced CSV loader with better structure parsing"""
    documents = []
    try:
        # Read the CSV
        df = pd.read_csv(file_path)
        
        # Add metadata about the CSV structure
        row_count = len(df)
        columns = list(df.columns)
        
        # Create summary documents
        documents.append(Document(
            page_content=f"CSV file {file_path.name} contains {row_count} rows with columns: {', '.join(columns)}",
            metadata={'source': file_path.name, 'type': 'csv_summary'}
        ))
        
        # Add column headers info
        documents.append(Document(
            page_content=f"Column headers in {file_path.name}: {', '.join(columns)}",
            metadata={'source': file_path.name, 'type': 'csv_headers'}
        ))
        
        # Add sample data
        sample_data = df.head(3).to_string(index=False)
        documents.append(Document(
            page_content=f"Sample data from {file_path.name}:\n{sample_data}",
            metadata={'source': file_path.name, 'type': 'csv_sample'}
        ))
        
        # Add individual row information for specific queries
        for idx, row in df.iterrows():
            row_text = " | ".join([f"{col}: {row[col]}" for col in df.columns])
            documents.append(Document(
                page_content=f"Row {idx + 1} from {file_path.name}: {row_text}",
                metadata={'source': file_path.name, 'type': 'csv_row', 'row_number': idx + 1}
            ))
        
        # Add project-specific information if Project column exists
        if 'Project' in df.columns:
            project_list = df['Project'].unique().tolist()
            documents.append(Document(
                page_content=f"Projects in {file_path.name}: {', '.join(map(str, project_list))}",
                metadata={'source': file_path.name, 'type': 'csv_projects'}
            ))
            
            # Add owner information if Owner column exists
            if 'Owner' in df.columns:
                for _, row in df.iterrows():
                    documents.append(Document(
                        page_content=f"Project {row['Project']} is owned by {row['Owner']}",
                        metadata={'source': file_path.name, 'type': 'csv_ownership'}
                    ))
        
        logger.info(f"Loaded {len(documents)} documents from CSV {file_path.name}")
        
    except Exception as e:
        logger.error(f"Error loading CSV {file_path}: {str(e)}")
        # Fallback to standard CSV loader
        try:
            fallback_docs = CSVLoader(str(file_path)).load()
            for doc in fallback_docs:
                doc.metadata['source'] = file_path.name
            return fallback_docs
        except:
            return []
    
    return documents

def load_excel_enhanced(file_path: Path) -> List[Document]:
    """Enhanced Excel loader"""
    documents = []
    try:
        # Read the Excel file
        df = pd.read_excel(file_path)
        
        # Add metadata about the Excel structure
        row_count = len(df)
        columns = list(df.columns)
        
        # Create summary documents
        documents.append(Document(
            page_content=f"Excel file {file_path.name} contains {row_count} data rows with columns: {', '.join(columns)}",
            metadata={'source': file_path.name, 'type': 'excel_summary'}
        ))
        
        # Add column headers info
        documents.append(Document(
            page_content=f"Column names in {file_path.name}: {', '.join(columns)}",
            metadata={'source': file_path.name, 'type': 'excel_headers'}
        ))
        
        # Add sample data
        sample_data = df.head(3).to_string(index=False)
        documents.append(Document(
            page_content=f"Sample data from {file_path.name}:\n{sample_data}",
            metadata={'source': file_path.name, 'type': 'excel_sample'}
        ))
        
        # Add individual row information
        for idx, row in df.iterrows():
            row_text = " | ".join([f"{col}: {row[col]}" for col in df.columns])
            documents.append(Document(
                page_content=f"Row {idx + 1} from {file_path.name}: {row_text}",
                metadata={'source': file_path.name, 'type': 'excel_row', 'row_number': idx + 1}
            ))
        
        logger.info(f"Loaded {len(documents)} documents from Excel {file_path.name}")
        
    except Exception as e:
        logger.error(f"Error loading Excel {file_path}: {str(e)}")
        # Fallback to unstructured loader
        try:
            fallback_docs = UnstructuredExcelLoader(str(file_path)).load()
            for doc in fallback_docs:
                doc.metadata['source'] = file_path.name
            return fallback_docs
        except:
            return []
    
    return documents

def load_docx_enhanced(file_path: Path) -> List[Document]:
    """Enhanced DOCX loader with table parsing"""
    documents = []
    try:
        try:
            import docx
            doc = docx.Document(file_path)
            
            # Extract tables
            if doc.tables:
                for table_idx, table in enumerate(doc.tables):
                    # Get headers
                    headers = [cell.text.strip() for cell in table.rows[0].cells]
                    
                    # Add table structure info
                    documents.append(Document(
                        page_content=f"Table {table_idx + 1} in {file_path.name} has columns: {', '.join(headers)}",
                        metadata={'source': file_path.name, 'type': 'docx_table_headers'}
                    ))
                    
                    # Process each row
                    for row_idx, row in enumerate(table.rows[1:], 1):
                        row_data = {}
                        row_text_parts = []
                        
                        for header, cell in zip(headers, row.cells):
                            cell_value = cell.text.strip()
                            row_data[header] = cell_value
                            row_text_parts.append(f"{header}: {cell_value}")
                        
                        row_text = " | ".join(row_text_parts)
                        documents.append(Document(
                            page_content=f"Table row {row_idx} from {file_path.name}: {row_text}",
                            metadata={'source': file_path.name, 'type': 'docx_table_row', 'row_number': row_idx}
                        ))
                        
                        # Add specific project information
                        if 'Project' in row_data:
                            for key, value in row_data.items():
                                if key != 'Project':
                                    documents.append(Document(
                                        page_content=f"Project {row_data['Project']} has {key}: {value}",
                                        metadata={'source': file_path.name, 'type': 'docx_project_info'}
                                    ))
        except ImportError:
            logger.warning("python-docx not available, using fallback loader")
        
        # Also load regular text content
        fallback_docs = Docx2txtLoader(str(file_path)).load()
        for doc in fallback_docs:
            doc.metadata['source'] = file_path.name
            doc.metadata['type'] = 'docx_text'
        documents.extend(fallback_docs)
        
        logger.info(f"Loaded {len(documents)} documents from DOCX {file_path.name}")
        
    except Exception as e:
        logger.error(f"Error loading DOCX {file_path}: {str(e)}")
        # Fallback to standard loader
        try:
            fallback_docs = Docx2txtLoader(str(file_path)).load()
            for doc in fallback_docs:
                doc.metadata['source'] = file_path.name
            return fallback_docs
        except:
            return []
    
    return documents

def load_pdf_enhanced(file_path: Path) -> List[Document]:
    """Enhanced PDF loader"""
    documents = []
    try:
        loader = PyPDFLoader(str(file_path))
        pdf_docs = loader.load()
        
        # Add source metadata
        for doc in pdf_docs:
            doc.metadata['source'] = file_path.name
            doc.metadata['type'] = 'pdf_content'
        
        documents.extend(pdf_docs)
        
        # Create a summary document
        all_text = " ".join([doc.page_content for doc in pdf_docs])
        documents.append(Document(
            page_content=f"PDF {file_path.name} contains the following content: {all_text[:1000]}...",
            metadata={'source': file_path.name, 'type': 'pdf_summary'}
        ))
        
        logger.info(f"Loaded {len(documents)} documents from PDF {file_path.name}")
        
    except Exception as e:
        logger.error(f"Error loading PDF {file_path}: {str(e)}")
        return []
    
    return documents

def load_text_enhanced(file_path: Path) -> List[Document]:
    """Enhanced text loader"""
    documents = []
    try:
        loader = TextLoader(str(file_path), encoding='utf-8')
        text_docs = loader.load()
        
        for doc in text_docs:
            doc.metadata['source'] = file_path.name
            doc.metadata['type'] = 'text_content'
        
        documents.extend(text_docs)
        
        # Look for bullet points in text
        content = text_docs[0].page_content if text_docs else ""
        if "•" in content or "1." in content or "2." in content:
            # Extract bullet points
            lines = content.split('\n')
            bullet_points = []
            for line in lines:
                line = line.strip()
                if line.startswith('•') or line.startswith('1.') or line.startswith('2.'):
                    bullet_points.append(line)
            
            if bullet_points:
                documents.append(Document(
                    page_content=f"Bullet points from {file_path.name}: {' '.join(bullet_points)}",
                    metadata={'source': file_path.name, 'type': 'text_bullets'}
                ))
        
        logger.info(f"Loaded {len(documents)} documents from text {file_path.name}")
        
    except Exception as e:
        logger.error(f"Error loading text {file_path}: {str(e)}")
        return []
    
    return documents

def load_document(file_path: Path) -> List[Document]:
    """Load a single document based on its file type with enhanced parsing"""
    try:
        file_extension = file_path.suffix.lower()
        
        if file_extension == '.pdf':
            documents = load_pdf_enhanced(file_path)
        elif file_extension == '.txt':
            documents = load_text_enhanced(file_path)
        elif file_extension == '.docx':
            documents = load_docx_enhanced(file_path)
        elif file_extension == '.csv':
            documents = load_csv_enhanced(file_path)
        elif file_extension == '.xlsx':
            documents = load_excel_enhanced(file_path)
        else:
            logger.warning(f"Unsupported file type: {file_extension}")
            return []
        
        logger.info(f"Loaded {len(documents)} documents from {file_path.name}")
        return documents
        
    except Exception as e:
        logger.error(f"Error loading {file_path}: {str(e)}")
        return []

def load_all_documents(directory: Path = None) -> List[Document]:
    """Load all supported documents from the specified directory"""
    if directory is None:
        directory = UPLOAD_DIR if UPLOAD_DIR.exists() else DATA_DIR
    
    all_documents = []
    files = get_supported_files(directory)
    
    if not files:
        logger.warning(f"No supported files found in {directory}")
        return []
    
    for file_path in files:
        documents = load_document(file_path)
        all_documents.extend(documents)
    
    logger.info(f"Loaded {len(all_documents)} total documents from {directory}")
    return all_documents

def split_documents(documents: List[Document]) -> List[Document]:
    """Split documents into chunks with improved strategy"""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )
    
    chunks = text_splitter.split_documents(documents)
    logger.info(f"Split documents into {len(chunks)} chunks")
    return chunks

def create_vector_store(chunks: List[Document]) -> Chroma:
    """Create and populate the vector store with error handling"""
    try:
        # Clean existing database first
        clean_chroma_db()
        
        # Initialize embeddings with error handling
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            model_kwargs={'device': 'cpu'}
        )
        
        # Create vector store - FIXED: Remove persist() call
        vectorstore = Chroma.from_documents(
            documents=chunks,
            embedding=embeddings,
            persist_directory=CHROMA_DB_DIR
        )
        
        logger.info(f"Successfully created vector store with {len(chunks)} chunks")
        return vectorstore
        
    except Exception as e:
        logger.error(f"Error creating vector store: {str(e)}")
        raise

def clean_chroma_db():
    """Clean existing ChromaDB directory"""
    if os.path.exists(CHROMA_DB_DIR):
        try:
            shutil.rmtree(CHROMA_DB_DIR)
            logger.info(f"Cleaned existing ChromaDB directory: {CHROMA_DB_DIR}")
        except Exception as e:
            logger.warning(f"Could not clean ChromaDB directory: {str(e)}")

def test_vector_store():
    """Test the vector store with a simple query"""
    try:
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            model_kwargs={'device': 'cpu'}
        )
        
        vectorstore = Chroma(
            persist_directory=CHROMA_DB_DIR,
            embedding_function=embeddings
        )
        
        # Test query
        results = vectorstore.similarity_search("test", k=1)
        logger.info(f"✅ Vector store test passed - found {len(results)} results")
        
    except Exception as e:
        logger.error(f"❌ Vector store test failed: {str(e)}")
        raise

def ingest_documents(directory: Path = None):
    """Main ingestion function"""
    try:
        # Load documents
        documents = load_all_documents(directory)
        if not documents:
            logger.error("No documents loaded. Please check your data directory.")
            return None
        
        # Split documents
        chunks = split_documents(documents)
        
        # Create vector store
        vectorstore = create_vector_store(chunks)
        
        logger.info("✅ Document ingestion completed successfully!")
        return vectorstore
        
    except Exception as e:
        logger.error(f"❌ Document ingestion failed: {str(e)}")
        raise

def ingest_uploaded_documents(directory_path: str):
    """
    Reusable ingestion function that accepts a directory path (e.g., for Gradio uploads).
    """
    try:
        return ingest_documents(Path(directory_path))
    except Exception as e:
        logger.error(f"❌ Error during uploaded document ingestion: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        vectorstore = ingest_documents()
        if vectorstore:
            test_vector_store()
    except Exception as e:
        logger.error(f"Ingestion process failed: {str(e)}")
        exit(1)
